#include <stdio.h>
#include <conio.h>
#include <graphics.h>
#include <stdlib.h>

void InitVGA(void);
void retal(int, int, int, int, int);

void InitVGA(){
	int Gd, Gm;
	char GrErr;
	Gd=DETECT;
	initgraph(&Gd,&Gm,"k:\\bgi");
	GrErr = graphresult();
	if (GrErr != grOk){
		printf("Erro grafico: %s\n",grapherrormsg(GrErr));
		exit(1);
	}
}


void reta3(int x1, int y1, int x2, int y2, int cor){
	
	int dx = x2-x1; int dy= y2-y1;
	int passos,k,x=x1,y=y1;
	float xinc, yinc;
	
	if(abs(dx) > abs(dy)){
		passos=abs(dx);
	}		
	else{
		passos=abs(dy);
	}
	
	xinc=dx/(float)passos;
	yinc=dy/(float)passos;
	putpixel(x,y,cor);
	
	for(k=0; k< passos;k++){
		x+=xinc;
		y+=yinc;
		putpixel(x,y,cor);
	}

}

void reta4(int x1, int y1, int x2, int y2, int cor){
	int dy,dx;

	 dy=y2-y1;
	 dx=x2-x1;
	int xi = 1;
	if (dx <= 0){
		xi = -1;
		dx = -dx;
		
		int d=(2*dx) - dy;
		int x=x1, y=y1;
		
		putpixel(x,y,cor);
		
		for(y; y <= y2; y++){
			
			if (d > 0){
				x = x +xi;
				d = d + (2*(dx-dy));
			}
			else{
				d = d + (dx*2);
			}
			putpixel(x,y,cor);
		} 
	}
	else{
		
		
		int d=(2*dy) - dx;
		int incE= 2*dy;
		int incNE=2*(dy-dx);
		int x=x1, y=y1;
		
		while(x < x2){
			if(d < 0){
				d+=incE;
				y=y;
				x++;
			}
			else{
				d+=incNE;
				x++;
				y++;
			}
			putpixel(x,y,cor);
		}
		
	}
}


void main(){
	int x1, y1, x2, y2,cor;
	InitVGA();		
	randomize();
	
	
	/*poligono*/
	reta4(200,75,400,75,WHITE);
	reta4(200,75,200,200,WHITE);
	reta4(400,75,400,200,WHITE);	
	reta4(200,200,300,400,WHITE);	
	reta4(400,200,300,300,WHITE);
	

	
	
	getch();
	closegraph();
	
}

